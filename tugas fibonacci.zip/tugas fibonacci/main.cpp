#include <iostream>

using namespace std;

int main(){
    cout << "Bil Fibonacci kurang dr 100:" << endl;
    int n = 100;
    int t1 = 0;
    int t2 = 1;
    int h;

    h = t1 + t2;

    while(h <= n) {
        cout << h << endl;
        t1 = t2;
        t2 = h;
        h = t1 + t2;
    }

    return 0;
}
